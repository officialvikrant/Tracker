package com.example.avtracker
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import android.webkit.WebView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var latitudeTextView: TextView
    private lateinit var longitudeTextView: TextView
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        latitudeTextView = findViewById(R.id.textView2)
        longitudeTextView = findViewById(R.id.textView4)
        webView = findViewById(R.id.web_view)
        webView.settings.javaScriptEnabled=true
        webView.settings.javaScriptCanOpenWindowsAutomatically=true
        // Load a URL
        val smsReceiver = SmsReceiver()
        val intentFilter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        registerReceiver(smsReceiver, intentFilter)
        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
            val phoneNumber = "+919676655675"
            val message = "Location"
            val subscriptionId = SmsManager.getDefaultSmsSubscriptionId()
            val smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)

            // Send the message
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        }

        val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener {
            val phoneNumber = "+919676655675"
            val message = "Buzz"

            val smsManager = SmsManager.getDefault()

            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        }
    }
    inner class SmsReceiver : BroadcastReceiver() {

        private var lat: Double = 0.0
        private var lon: Double = 0.0
        override fun onReceive(context: Context?, intent: Intent?) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            val messageBody = messages[0].messageBody
            val sender = messages[0].originatingAddress
            if (sender == "+918148034834") {
                val pattern = "([-+]?[0-9]*\\.?[0-9]+),([-+]?[0-9]*\\.?[0-9]+)"
                val matcher = Pattern.compile(pattern).matcher(messageBody)
                if (matcher.find()) {
                    lat = matcher.group(1).toDouble()
                    lon = matcher.group(2).toDouble()
                    latitudeTextView.text = lat.toString()
                    longitudeTextView.text = lon.toString()
                    webView.loadUrl("https://www.google.com/maps/search/?api=1&query=$lat%2C$lon")
                }
            }
        }
    }
}


